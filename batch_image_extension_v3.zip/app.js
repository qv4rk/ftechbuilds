/**
 * Batch Image Pipeline v3.0 — Complete Frontend Controller
 */

document.addEventListener('DOMContentLoaded', async () => {
  const queueBody = document.getElementById('queueBody');
  const queueCountLabel = document.getElementById('queueCountLabel');
  const globalStylePrefixInput = document.getElementById('globalStylePrefix');
  const applyGlobalStyleBtn = document.getElementById('applyGlobalStyleBtn');
  const addRowBtn = document.getElementById('addRowBtn');
  const clearQueueBtn = document.getElementById('clearQueueBtn');
  const importBtn = document.getElementById('importBtn');
  const importFile = document.getElementById('importFile');
  const exportBtn = document.getElementById('exportBtn');
  const exportMdBtn = document.getElementById('exportMdBtn');
  const loadBundledBtn = document.getElementById('loadBundledBtn');
  const chapterFilter = document.getElementById('chapterFilter');

  // Quick Multi-Line Composer
  const toggleComposerBtn = document.getElementById('toggleComposerBtn');
  const quickComposerBox = document.getElementById('quickComposerBox');
  const quickComposerInput = document.getElementById('quickComposerInput');
  const appendComposerRowsBtn = document.getElementById('appendComposerRowsBtn');
  const replaceComposerRowsBtn = document.getElementById('replaceComposerRowsBtn');
  const openFirstComposerUrlBtn = document.getElementById('openFirstComposerUrlBtn');

  // Batch Controls
  const runBatchBtn = document.getElementById('runBatchBtn');
  const pauseBatchBtn = document.getElementById('pauseBatchBtn');
  const cancelBatchBtn = document.getElementById('cancelBatchBtn');
  const savePartialBtn = document.getElementById('savePartialBtn');
  const pickLocalFolderBtn = document.getElementById('pickLocalFolderBtn');
  const localFolderBadge = document.getElementById('localFolderBadge');
  const clearVaultCacheBtn = document.getElementById('clearVaultCacheBtn');
  const vaultPersistBadge = document.getElementById('vaultPersistBadge');

  // Proxy Controls
  const proxyToggle = document.getElementById('proxyToggle');
  const proxyBadge = document.getElementById('proxyBadge');
  const proxyCountBadge = document.getElementById('proxyCountBadge');
  const cycleProxyEveryReq = document.getElementById('cycleProxyEveryReq');
  const rotateProxyBtn = document.getElementById('rotateProxyBtn');
  const importProxyBtn = document.getElementById('importProxyBtn');
  const importProxyFile = document.getElementById('importProxyFile');
  const refreshProxyBtn = document.getElementById('refreshProxyBtn');

  // API Key Vault Controls
  const apiKeyInput = document.getElementById('apiKeyInput');
  const manualKeyProvider = document.getElementById('manualKeyProvider');
  const addApiKeysBtn = document.getElementById('addApiKeysBtn');
  const clearApiKeysBtn = document.getElementById('clearApiKeysBtn');
  const keyChipsContainer = document.getElementById('keyChipsContainer');
  const providerModeSelect = document.getElementById('providerMode');

  // Pacing & Image Params
  const dirNameInput = document.getElementById('dirName');
  const delaySecInput = document.getElementById('delaySec');
  const jitterSecInput = document.getElementById('jitterSec');
  const cooldownSecInput = document.getElementById('cooldownSec');
  const reqTimeoutSecInput = document.getElementById('reqTimeoutSec');
  const startRowInput = document.getElementById('startRow');
  const rejectDuplicatesCheckbox = document.getElementById('rejectDuplicates');
  const trimModeSelect = document.getElementById('trimMode');
  const trimPxInput = document.getElementById('trimPxInput');
  const imgWidthInput = document.getElementById('imgWidth');
  const imgHeightInput = document.getElementById('imgHeight');
  const noLogoCheckbox = document.getElementById('noLogoParam');
  const sceneFirstCheckbox = document.getElementById('sceneFirstOrder');

  // Status & Progress
  const progressBar = document.getElementById('progressBar');
  const statusMessage = document.getElementById('statusMessage');
  const countdownPill = document.getElementById('countdownPill');
  const statusCounter = document.getElementById('statusCounter');

  // Preview Gallery Elements
  const imagePreview = document.getElementById('imagePreview');
  const placeholderText = document.getElementById('placeholderText');
  const galleryCounterLabel = document.getElementById('galleryCounterLabel');
  const prevPreviewBtn = document.getElementById('prevPreviewBtn');
  const nextPreviewBtn = document.getElementById('nextPreviewBtn');
  const previewFileTitle = document.getElementById('previewFileTitle');
  const saveSingleNowBtn = document.getElementById('saveSingleNowBtn');
  const previewOpenTabBtn = document.getElementById('previewOpenTabBtn');
  const previewCopyPromptBtn = document.getElementById('previewCopyPromptBtn');
  const previewCopyUrlBtn = document.getElementById('previewCopyUrlBtn');
  const previewListenBtn = document.getElementById('previewListenBtn');

  // Debug Console & Modals
  const debugTracker = document.getElementById('debugTracker');
  const copyDebugLogBtn = document.getElementById('copyDebugLogBtn');
  const clearDebugLogBtn = document.getElementById('clearDebugLogBtn');
  const ttsStatusBtn = document.getElementById('ttsStatusBtn');
  const ttsStopBtn = document.getElementById('ttsStopBtn');
  const openApiKeyHelpBtn = document.getElementById('openApiKeyHelpBtn');
  const openApiKeyHelpBtn2 = document.getElementById('openApiKeyHelpBtn2');
  const closeApiKeyModalBtn = document.getElementById('closeApiKeyModalBtn');
  const apiKeyModal = document.getElementById('apiKeyModal');
  const listenApiKeyGuideBtn = document.getElementById('listenApiKeyGuideBtn');
  const openHelpBtn = document.getElementById('openHelpBtn');
  const closeHelpModalBtn = document.getElementById('closeHelpModalBtn');
  const helpModal = document.getElementById('helpModal');
  const listenHelpGuideBtn = document.getElementById('listenHelpGuideBtn');
  const toastBanner = document.getElementById('toastBanner');

  const DEFAULT_BOOK_STYLE = (
    "Book illustration in hand-drawn ink line with ochre and soot watercolor washes " +
    "on warm cream paper (paper ede4d4, ink 2a2218, rust accents 6b3a2a), loose " +
    "cross-hatching, 19th-century travel-sketchbook style. Realistic, dignified, no " +
    "caricature, no gore. No text, no lettering, no captions, no border, no signature. 16:9."
  );

  // Runtime State
  let savedApiKeys = [];
  let keyCursor = 0;
  let modelCursor = 0;
  const POLLINATIONS_MODELS = ['flux', 'turbo', 'flux-realism'];

  let masterZip = new JSZip();
  const savedBlobs = new Map();       // fileName -> Blob
  const seenImageHashes = new Set();  // SHA-256 hex strings
  const seenDHashes = [];             // 64-bit binary strings for perceptual similarity
  const galleryItems = [];            // { fileName, blob, objectUrl, fullPrompt, targetUrl, providerLabel, dims }
  let currentGalleryIndex = -1;
  let localDirHandle = null;

  let isRunning = false;
  let isPaused = false;
  let isCancelled = false;
  let activeAbortController = null;

  // --- Non-blocking Toast Notification (replaces alert()) ---
  let toastTimer = null;
  function showToast(msg, isError = false) {
    if (!toastBanner) return;
    toastBanner.textContent = msg;
    toastBanner.style.borderLeftColor = isError ? '#f87171' : '#4ade80';
    toastBanner.style.display = 'block';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastBanner.style.display = 'none';
    }, 3800);
  }

  // --- Safe Clipboard Helper (works in Extension and Canvas iframe) ---
  async function copyTextSafe(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (_) {}
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      return true;
    } catch (_) {
      return false;
    }
  }

  // --- Debug Logger ---
  function logDebug(msg, level = 'info') {
    const ts = new Date().toLocaleTimeString();
    const line = document.createElement('div');
    line.className = `log-${level}`;
    line.textContent = `[${ts}] ${msg}`;
    debugTracker.appendChild(line);
    debugTracker.scrollTop = debugTracker.scrollHeight;
  }

  copyDebugLogBtn.addEventListener('click', async () => {
    await copyTextSafe(debugTracker.innerText || '');
    showToast('Copied debug log to clipboard.');
    logDebug('Copied debug log to clipboard.', 'ok');
  });

  clearDebugLogBtn.addEventListener('click', () => {
    debugTracker.innerHTML = '';
  });

  // --- IndexedDB Crash-Proof Vault ---
  function openVaultDB() {
    return new Promise((resolve) => {
      try {
        if (!('indexedDB' in window)) return resolve(null);
        const req = indexedDB.open('BatchImageVaultDB_v3', 1);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains('images')) {
            db.createObjectStore('images', { keyPath: 'fileName' });
          }
        };
        req.onsuccess = (e) => resolve(e.target.result);
        req.onerror = () => resolve(null);
      } catch (_) {
        resolve(null);
      }
    });
  }

  async function saveImageToVaultDB(record) {
    const db = await openVaultDB();
    if (!db) return;
    return new Promise((resolve) => {
      try {
        const tx = db.transaction('images', 'readwrite');
        tx.objectStore('images').put(record);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      } catch (_) {
        resolve(false);
      }
    });
  }

  async function loadAllFromVaultDB() {
    const db = await openVaultDB();
    if (!db) return [];
    return new Promise((resolve) => {
      try {
        const tx = db.transaction('images', 'readonly');
        const req = tx.objectStore('images').getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => resolve([]);
      } catch (_) {
        resolve([]);
      }
    });
  }

  async function clearVaultDB() {
    const db = await openVaultDB();
    if (!db) return;
    return new Promise((resolve) => {
      try {
        const tx = db.transaction('images', 'readwrite');
        tx.objectStore('images').clear();
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      } catch (_) {
        resolve(false);
      }
    });
  }

  function updateVaultBadge() {
    vaultPersistBadge.textContent = `Vault: ${savedBlobs.size} saved`;
    savePartialBtn.disabled = savedBlobs.size === 0;
    savePartialBtn.textContent = `📦 Download Zip Folder (${savedBlobs.size})`;
    const totalRows = queueBody.querySelectorAll('tr').length;
    statusCounter.textContent = `${savedBlobs.size} / ${totalRows} confirmed in folder`;
  }

  clearVaultCacheBtn.addEventListener('click', async () => {
    await clearVaultDB();
    savedBlobs.clear();
    seenImageHashes.clear();
    seenDHashes.length = 0;
    galleryItems.length = 0;
    masterZip = new JSZip();
    showGalleryIndex(-1);
    updateVaultBadge();
    queueBody.querySelectorAll('tr').forEach(r => {
      r.classList.remove('completed-row', 'error-row', 'active-row');
      const tag = r.querySelector('.row-status-tag');
      if (tag) { tag.className = 'row-status-tag'; tag.textContent = 'Pending'; }
      const sb = r.querySelector('.row-save-btn');
      if (sb) sb.disabled = true;
    });
    showToast('Cleared IndexedDB image vault.');
    logDebug('Cleared IndexedDB image vault and reset in-memory Zip.', 'warn');
  });

  // --- Direct Local Disk Folder Auto-Save (File System Access API) ---
  pickLocalFolderBtn.addEventListener('click', async () => {
    if (!('showDirectoryPicker' in window)) {
      showToast('Direct Folder linking requires Desktop Chrome/Edge. Using IndexedDB + Zip mode.', true);
      return;
    }
    try {
      localDirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
      localFolderBadge.className = 'status-badge active';
      localFolderBadge.textContent = `Disk: ${localDirHandle.name}/`;
      showToast(`Linked local folder "${localDirHandle.name}" for instant auto-save!`);
      logDebug(`📁 Linked local disk directory "${localDirHandle.name}" — confirmed images will write directly to disk.`, 'ok');
    } catch (err) {
      logDebug(`Folder picker cancelled or blocked: ${err.message}`, 'warn');
    }
  });

  async function writeBlobToLocalDir(fileName, blob) {
    if (!localDirHandle) return false;
    try {
      const fileHandle = await localDirHandle.getFileHandle(fileName, { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(blob);
      await writable.close();
      return true;
    } catch (err) {
      logDebug(`Local disk write warning for ${fileName}: ${err.message}`, 'warn');
      return false;
    }
  }

  // --- Accessibility: Web Speech API Text-to-Speech ---
  function speakText(text) {
    if (!('speechSynthesis' in window)) {
      showToast('Text-to-speech is not supported in this browser.', true);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(String(text || '').trim());
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
  }

  function stopSpeaking() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  ttsStatusBtn.addEventListener('click', () => {
    const currentItem = galleryItems[currentGalleryIndex];
    const extra = currentItem ? ` Currently viewing ${currentItem.fileName}. ${currentItem.fullPrompt}` : '';
    speakText(`${statusMessage.textContent}. ${statusCounter.textContent}.${extra}`);
  });

  ttsStopBtn.addEventListener('click', stopSpeaking);

  // --- Modals ---
  openApiKeyHelpBtn.addEventListener('click', () => apiKeyModal.classList.add('open'));
  openApiKeyHelpBtn2.addEventListener('click', () => apiKeyModal.classList.add('open'));
  closeApiKeyModalBtn.addEventListener('click', () => {
    stopSpeaking();
    apiKeyModal.classList.remove('open');
  });
  listenApiKeyGuideBtn.addEventListener('click', () => {
    speakText(document.getElementById('apiKeyGuideText').innerText);
  });

  openHelpBtn.addEventListener('click', () => helpModal.classList.add('open'));
  closeHelpModalBtn.addEventListener('click', () => {
    stopSpeaking();
    helpModal.classList.remove('open');
  });
  listenHelpGuideBtn.addEventListener('click', () => {
    speakText(document.getElementById('helpGuideText').innerText);
  });

  // --- 1. Unlimited Auto-Recognized API Key Vault ---
  function detectApiKeyProvider(rawKey, manualOverride = 'auto') {
    if (manualOverride && manualOverride !== 'auto') return manualOverride;
    const k = rawKey.trim();
    if (/^AIza[0-9A-Za-z\-_]{20,}$/.test(k)) return 'gemini';
    if (/^(pk|sk)_[0-9A-Za-z\-_]{10,}$/.test(k)) return 'pollinations';
    if (/^hf_[0-9A-Za-z]{20,}$/.test(k)) return 'huggingface';
    if (/^sk-[0-9A-Za-z\-_]{20,}$/.test(k)) return 'openai';
    return 'aihorde';
  }

  function providerDisplayName(provider) {
    const map = {
      gemini: 'Google Gemini',
      pollinations: 'Pollinations',
      huggingface: 'HuggingFace FLUX',
      openai: 'OpenAI',
      aihorde: 'AI Horde'
    };
    return map[provider] || provider;
  }

  function maskKeyString(k) {
    if (k.length <= 10) return k;
    return `${k.slice(0, 6)}...${k.slice(-4)}`;
  }

  function renderKeyChips() {
    keyChipsContainer.innerHTML = '';
    if (savedApiKeys.length === 0) {
      const empty = document.createElement('span');
      empty.style.fontSize = '0.8rem';
      empty.style.color = '#64748b';
      empty.textContent = 'No custom keys added yet — using built-in keyless rotation (Pollinations multi-model + AI Horde 0000000000). Paste any keys above for faster authenticated cycling.';
      keyChipsContainer.appendChild(empty);
      return;
    }

    savedApiKeys.forEach((item, index) => {
      const chip = document.createElement('div');
      chip.className = 'key-chip';
      chip.innerHTML = `
        <span class="provider-tag ${item.provider}">${providerDisplayName(item.provider)}</span>
        <code>${maskKeyString(item.key)}</code>
        <span style="color:#64748b;">(${item.uses || 0} uses)</span>
        <button type="button" title="Remove key">&times;</button>
      `;
      chip.querySelector('button').addEventListener('click', () => {
        savedApiKeys.splice(index, 1);
        saveSetting('savedApiKeys', savedApiKeys);
        renderKeyChips();
        logDebug(`Removed ${providerDisplayName(item.provider)} key (${maskKeyString(item.key)}).`, 'warn');
      });
      keyChipsContainer.appendChild(chip);
    });
  }

  addApiKeysBtn.addEventListener('click', () => {
    const raw = apiKeyInput.value.trim();
    if (!raw) return;
    const tokens = raw.split(/[\r\n,]+/).map(s => s.trim()).filter(Boolean);
    let added = 0;

    tokens.forEach(token => {
      if (savedApiKeys.some(k => k.key === token)) return;
      const provider = detectApiKeyProvider(token, manualKeyProvider.value);
      savedApiKeys.push({
        id: `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        key: token,
        provider,
        uses: 0
      });
      added++;
      logDebug(`Auto-recognized & added ${providerDisplayName(provider)} API key: ${maskKeyString(token)}`, 'ok');
    });

    apiKeyInput.value = '';
    saveSetting('savedApiKeys', savedApiKeys);
    renderKeyChips();
    if (added > 0) {
      showToast(`Added ${added} API key(s) to rotation vault.`);
    }
  });

  clearApiKeysBtn.addEventListener('click', () => {
    savedApiKeys = [];
    saveSetting('savedApiKeys', savedApiKeys);
    renderKeyChips();
    logDebug('Cleared all custom API keys from vault.', 'warn');
  });

  // --- 2. Settings Persistence ---
  function saveSetting(key, val) {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ [key]: val });
      } else if ('localStorage' in window) {
        localStorage.setItem(`bip3_${key}`, JSON.stringify(val));
      }
    } catch (_) {}
  }

  async function loadSavedSettings() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        return await chrome.storage.local.get([
          'savedApiKeys', 'dirName', 'delaySec', 'jitterSec', 'cooldownSec', 'reqTimeoutSec',
          'startRow', 'rejectDuplicates', 'trimMode', 'trimPxInput', 'imgWidth', 'imgHeight',
          'noLogoParam', 'sceneFirstOrder', 'proxyEnabled', 'cycleProxyEveryReq', 'globalStylePrefix'
        ]);
      } else if ('localStorage' in window) {
        const out = {};
        for (const k of ['savedApiKeys', 'dirName', 'delaySec', 'jitterSec', 'cooldownSec', 'reqTimeoutSec', 'startRow', 'rejectDuplicates', 'trimMode', 'trimPxInput', 'imgWidth', 'imgHeight', 'noLogoParam', 'sceneFirstOrder', 'globalStylePrefix']) {
          const raw = localStorage.getItem(`bip3_${k}`);
          if (raw !== null) out[k] = JSON.parse(raw);
        }
        return out;
      }
    } catch (_) {}
    return {};
  }

  const savedCfg = await loadSavedSettings();
  if (Array.isArray(savedCfg.savedApiKeys)) savedApiKeys = savedCfg.savedApiKeys;
  if (savedCfg.dirName) dirNameInput.value = savedCfg.dirName;
  if (savedCfg.delaySec !== undefined) delaySecInput.value = savedCfg.delaySec;
  if (savedCfg.jitterSec !== undefined) jitterSecInput.value = savedCfg.jitterSec;
  if (savedCfg.cooldownSec !== undefined) cooldownSecInput.value = savedCfg.cooldownSec;
  if (savedCfg.reqTimeoutSec !== undefined) reqTimeoutSecInput.value = savedCfg.reqTimeoutSec;
  if (savedCfg.startRow !== undefined) startRowInput.value = savedCfg.startRow;
  if (savedCfg.rejectDuplicates !== undefined) rejectDuplicatesCheckbox.checked = savedCfg.rejectDuplicates;
  if (savedCfg.trimMode) trimModeSelect.value = savedCfg.trimMode;
  if (savedCfg.trimPxInput !== undefined) trimPxInput.value = savedCfg.trimPxInput;
  if (savedCfg.imgWidth) imgWidthInput.value = savedCfg.imgWidth;
  if (savedCfg.imgHeight) imgHeightInput.value = savedCfg.imgHeight;
  if (savedCfg.noLogoParam !== undefined) noLogoCheckbox.checked = savedCfg.noLogoParam;
  if (savedCfg.sceneFirstOrder !== undefined) sceneFirstCheckbox.checked = savedCfg.sceneFirstOrder;
  if (savedCfg.cycleProxyEveryReq !== undefined) cycleProxyEveryReq.checked = savedCfg.cycleProxyEveryReq;
  if (savedCfg.globalStylePrefix) globalStylePrefixInput.value = savedCfg.globalStylePrefix;

  renderKeyChips();

  // --- Proxy Pool Sync (Extension Environment) ---
  async function syncProxyStats(autoEnableIfChecked = false) {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      proxyCountBadge.textContent = 'Web/Canvas Mode (Direct Fetch)';
      proxyBadge.textContent = 'Browser IP';
      return;
    }
    try {
      const stats = await chrome.runtime.sendMessage({ action: 'getProxyStats' });
      if (stats && stats.ok) {
        proxyCountBadge.textContent = `Proxy Pool: ${stats.totalLoaded.toLocaleString()} ready (${stats.badCount} blacklisted)`;
        if (autoEnableIfChecked && proxyToggle.checked && !stats.activeProxy) {
          const sw = await chrome.runtime.sendMessage({ action: 'cycleNextProxy', markBad: false });
          if (sw && sw.ok) {
            proxyBadge.className = 'status-badge active';
            proxyBadge.textContent = sw.ip;
            logDebug(`Initial proxy activated: ${sw.ip} (${sw.totalLoaded} in pool)`, 'info');
          }
        } else if (stats.activeProxy) {
          proxyBadge.className = 'status-badge active';
          proxyBadge.textContent = `${stats.activeProxy.scheme}://${stats.activeProxy.host}:${stats.activeProxy.port}`;
        }
      }
    } catch (e) {
      proxyCountBadge.textContent = 'Direct Fetch Mode';
    }
  }

  syncProxyStats(true);

  async function switchProxyNext(markCurrentBad = false) {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) return null;
    try {
      proxyBadge.className = 'status-badge working';
      proxyBadge.textContent = 'Switching...';
      const res = await chrome.runtime.sendMessage({
        action: 'cycleNextProxy',
        markBad: markCurrentBad
      });
      if (res && res.ok) {
        proxyToggle.checked = true;
        proxyBadge.className = 'status-badge active';
        proxyBadge.textContent = res.ip;
        proxyCountBadge.textContent = `Proxy Pool: ${res.totalLoaded.toLocaleString()} ready (${res.badCount} blacklisted)`;
        logDebug(`Switched proxy -> ${res.ip} (Pool: ${res.totalLoaded} available, ${res.badCount} blacklisted)`, 'info');
        return res.ip;
      } else {
        proxyBadge.className = 'status-badge error';
        proxyBadge.textContent = 'Pool Empty';
        return null;
      }
    } catch (_) {
      return null;
    }
  }

  rotateProxyBtn.addEventListener('click', () => switchProxyNext(true));

  refreshProxyBtn.addEventListener('click', async () => {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      showToast('Proxy pool rotation runs when loaded as a Chrome/Kiwi Extension.');
      return;
    }
    proxyCountBadge.textContent = 'Refreshing from GitHub & ProxyScrape...';
    const res = await chrome.runtime.sendMessage({ action: 'refreshProxyPool' });
    if (res && res.ok) {
      proxyCountBadge.textContent = `Proxy Pool: ${res.totalLoaded.toLocaleString()} ready (0 blacklisted)`;
      logDebug(`Refreshed open-source proxy pool: ${res.totalLoaded.toLocaleString()} proxies loaded.`, 'ok');
    }
  });

  importProxyBtn.addEventListener('click', () => importProxyFile.click());
  importProxyFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        const res = await chrome.runtime.sendMessage({
          action: 'importProxyText',
          text: ev.target.result
        });
        if (res && res.ok) {
          proxyCountBadge.textContent = `Proxy Pool: ${res.totalLoaded.toLocaleString()} ready (${res.badCount} blacklisted)`;
          showToast(`Imported ${res.importedCount} custom proxies.`);
          logDebug(`Imported ${res.importedCount} custom proxies from ${file.name}.`, 'ok');
        }
      }
    };
    reader.readAsText(file);
    importProxyFile.value = '';
  });

  proxyToggle.addEventListener('change', async (e) => {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) return;
    if (e.target.checked) {
      await switchProxyNext(false);
    } else {
      await chrome.runtime.sendMessage({ action: 'toggleProxy', enabled: false });
      proxyBadge.className = 'status-badge';
      proxyBadge.textContent = 'Direct IP';
      logDebug('Proxy disabled — using direct internet connection.', 'warn');
    }
  });

  // --- 3. Separated Scene & Style Prefix Prompt Construction + Smart Pre-Pad ---
  function splitStyleAndScene(rawPrompt) {
    const text = String(rawPrompt || '').trim();
    const globalPrefix = globalStylePrefixInput.value.trim();

    const sceneIdx = text.indexOf('Scene:');
    if (sceneIdx > 0) {
      const stylePart = text.slice(0, sceneIdx).trim().replace(/#/g, '');
      const scenePart = text.slice(sceneIdx).trim();
      return { stylePrefix: stylePart, scene: scenePart };
    }

    if (text.startsWith('Book illustration in hand-drawn ink line')) {
      const cleaned = text.replace(/#/g, '');
      return { stylePrefix: globalPrefix, scene: cleaned };
    }

    return { stylePrefix: globalPrefix, scene: text };
  }

  function buildCleanFullPrompt(row) {
    const sceneRaw = row.querySelector('.row-scene').value.replace(/\s+/g, ' ').trim();
    const styleRaw = row.querySelector('.row-style-prefix').value.replace(/\s+/g, ' ').replace(/#/g, '').trim();

    if (!styleRaw) return sceneRaw;
    if (sceneRaw.includes(styleRaw.slice(0, 40))) return sceneRaw.replace(/#/g, '');

    if (sceneFirstCheckbox.checked) {
      return `${sceneRaw} Style: ${styleRaw}`;
    } else {
      return `${styleRaw} ${sceneRaw}`;
    }
  }

  function getRowTargetDimensions(row) {
    const titleVal = (row.querySelector('.row-title').value || '').toLowerCase();
    if (titleVal.includes('cover')) {
      return { width: 1024, height: 1572 };
    }
    return {
      width: Number(imgWidthInput.value) || 1536,
      height: Number(imgHeightInput.value) || 864
    };
  }

  /**
   * Builds Pollinations URL.
   * When trimMode === 'prepad_trim', requests (targetHeight + trimPx) so that after
   * cropping trimPx off the bottom, the saved image is EXACTLY (targetWidth x targetHeight)!
   */
  function buildTargetPollinationsUrl(row, seedOverride = null, modelOverride = 'flux') {
    const fullPrompt = buildCleanFullPrompt(row);
    const encodedQuery = encodeURIComponent(fullPrompt)
      .replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
    const dims = getRowTargetDimensions(row);
    const trimMode = trimModeSelect.value;
    const trimPx = Math.max(0, Number(trimPxInput.value) || 0);
    const requestHeight = trimMode === 'prepad_trim' ? dims.height + trimPx : dims.height;

    const nologo = noLogoCheckbox.checked ? 'true' : 'false';
    const seedPart = seedOverride !== null ? `&seed=${seedOverride}` : '';
    const modelPart = modelOverride ? `&model=${encodeURIComponent(modelOverride)}` : '';

    return `https://image.pollinations.ai/prompt/${encodedQuery}?width=${dims.width}&height=${requestHeight}&nologo=${nologo}${modelPart}${seedPart}`;
  }

  // --- 4. Preview Gallery Navigation & Single-Image "Save Now" ---
  function triggerSingleImageDownload(fileName, blob) {
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = fileName;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    showToast(`Saved ${fileName} (${(blob.size / 1024).toFixed(1)} KB)`);
    logDebug(`💾 Saved individual image to device: ${fileName} (${(blob.size / 1024).toFixed(1)} KB)`, 'ok');
  }

  function showGalleryIndex(idx) {
    if (galleryItems.length === 0 || idx < 0) {
      currentGalleryIndex = -1;
      imagePreview.style.display = 'none';
      placeholderText.style.display = 'block';
      prevPreviewBtn.disabled = true;
      nextPreviewBtn.disabled = true;
      saveSingleNowBtn.disabled = true;
      previewOpenTabBtn.disabled = true;
      previewCopyPromptBtn.disabled = true;
      previewCopyUrlBtn.disabled = true;
      previewListenBtn.disabled = true;
      galleryCounterLabel.textContent = 'No images rendered yet';
      previewFileTitle.textContent = '—';
      return;
    }

    currentGalleryIndex = Math.max(0, Math.min(idx, galleryItems.length - 1));
    const item = galleryItems[currentGalleryIndex];

    placeholderText.style.display = 'none';
    imagePreview.style.display = 'block';
    imagePreview.src = item.objectUrl;

    const dimText = item.dims ? ` • ${item.dims}` : '';
    galleryCounterLabel.textContent = `Image ${currentGalleryIndex + 1} of ${galleryItems.length} (${item.providerLabel}${dimText})`;
    previewFileTitle.textContent = `${item.fileName} (${(item.blob.size / 1024).toFixed(1)} KB)`;

    prevPreviewBtn.disabled = currentGalleryIndex <= 0;
    nextPreviewBtn.disabled = currentGalleryIndex >= galleryItems.length - 1;
    saveSingleNowBtn.disabled = false;
    previewOpenTabBtn.disabled = false;
    previewCopyPromptBtn.disabled = false;
    previewCopyUrlBtn.disabled = false;
    previewListenBtn.disabled = false;
  }

  prevPreviewBtn.addEventListener('click', () => {
    if (currentGalleryIndex > 0) showGalleryIndex(currentGalleryIndex - 1);
  });

  nextPreviewBtn.addEventListener('click', () => {
    if (currentGalleryIndex < galleryItems.length - 1) showGalleryIndex(currentGalleryIndex + 1);
  });

  saveSingleNowBtn.addEventListener('click', () => {
    if (currentGalleryIndex >= 0 && galleryItems[currentGalleryIndex]) {
      const item = galleryItems[currentGalleryIndex];
      triggerSingleImageDownload(item.fileName, item.blob);
    }
  });

  previewOpenTabBtn.addEventListener('click', () => {
    if (currentGalleryIndex >= 0 && galleryItems[currentGalleryIndex]) {
      window.open(galleryItems[currentGalleryIndex].targetUrl, '_blank', 'noopener');
    }
  });

  previewCopyPromptBtn.addEventListener('click', async () => {
    if (currentGalleryIndex >= 0 && galleryItems[currentGalleryIndex]) {
      await copyTextSafe(galleryItems[currentGalleryIndex].fullPrompt);
      showToast(`Copied clean prompt for ${galleryItems[currentGalleryIndex].fileName}`);
      logDebug(`📋 Copied clean prompt (no %20) for ${galleryItems[currentGalleryIndex].fileName}`, 'ok');
    }
  });

  previewCopyUrlBtn.addEventListener('click', async () => {
    if (currentGalleryIndex >= 0 && galleryItems[currentGalleryIndex]) {
      await copyTextSafe(galleryItems[currentGalleryIndex].targetUrl);
      showToast(`Copied encoded URL for ${galleryItems[currentGalleryIndex].fileName}`);
      logDebug(`🔗 Copied encoded URL for ${galleryItems[currentGalleryIndex].fileName}`, 'ok');
    }
  });

  previewListenBtn.addEventListener('click', () => {
    if (currentGalleryIndex >= 0 && galleryItems[currentGalleryIndex]) {
      speakText(galleryItems[currentGalleryIndex].fullPrompt);
    }
  });

  // --- 5. Queue Table Row Builder ---
  function updateRowIndices() {
    const rows = queueBody.querySelectorAll('tr');
    rows.forEach((row, idx) => {
      const numEl = row.querySelector('.row-num');
      if (numEl) numEl.textContent = idx + 1;
    });
    if (queueCountLabel) {
      queueCountLabel.textContent = `(${rows.length} row${rows.length === 1 ? '' : 's'})`;
    }
    statusCounter.textContent = `${savedBlobs.size} / ${rows.length} confirmed in folder`;
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function addRow(title = '', rawPromptOrScene = '', customStylePrefix = null) {
    const { stylePrefix, scene } = customStylePrefix !== null
      ? { stylePrefix: customStylePrefix, scene: rawPromptOrScene }
      : splitStyleAndScene(rawPromptOrScene);

    const cleanBase = (title.trim() || 'image').replace(/\.(jpg|jpeg|png|webp)$/i, '');
    const fileName = `${cleanBase}.jpg`;
    const alreadySaved = savedBlobs.has(fileName);

    const row = document.createElement('tr');
    if (alreadySaved) row.classList.add('completed-row');
    row.innerHTML = `
      <td style="text-align:center;">
        <div class="row-num" style="font-weight:700; color:#4a5568;"></div>
        <span class="row-status-tag ${alreadySaved ? 'done' : ''}">${alreadySaved ? '✅ In Vault' : 'Pending'}</span>
      </td>
      <td>
        <input type="text" class="row-title" value="${escapeHtml(fileName)}" placeholder="narr0016_imga.jpg">
        <div style="font-size:0.73rem; color:#718096;">Target: ${fileName.includes('cover') ? '1024×1572' : '1536×864 (16:9)'}</div>
      </td>
      <td>
        <textarea class="row-scene" rows="4" placeholder="Describe the unique scene here...">${escapeHtml(scene)}</textarea>
      </td>
      <td>
        <textarea class="row-style-prefix" rows="3" placeholder="Repeating style / front-end prefix...">${escapeHtml(stylePrefix)}</textarea>
      </td>
      <td>
        <div class="row-actions-grid">
          <button type="button" class="success small-btn row-run-btn" title="Generate ONLY this single row right now">▶ Run</button>
          <button type="button" class="primary small-btn row-save-btn" ${alreadySaved ? '' : 'disabled'} title="Save this row's generated image (.jpg) immediately">💾 Save Now</button>
          <button type="button" class="secondary small-btn row-open-url-btn" title="Open Pollinations URL in a new browser tab for manual click/save">↗ Open Tab</button>
          <button type="button" class="secondary small-btn row-copy-prompt-btn" title="Copy clean combined prompt (NO %20 encoding)">📋 Prompt</button>
          <button type="button" class="secondary small-btn row-copy-url-btn" title="Copy URL-encoded link">🔗 Copy URL</button>
          <button type="button" class="secondary small-btn row-listen-btn" title="Read this prompt aloud">🔊 Listen</button>
          <button type="button" class="danger small-btn row-del-btn" style="grid-column: span 2;" title="Remove row">✕ Remove Row</button>
        </div>
      </td>
    `;

    const runOneBtn = row.querySelector('.row-run-btn');
    const saveOneBtn = row.querySelector('.row-save-btn');
    const openUrlBtn = row.querySelector('.row-open-url-btn');
    const copyPromptBtn = row.querySelector('.row-copy-prompt-btn');
    const copyUrlBtn = row.querySelector('.row-copy-url-btn');
    const listenBtn = row.querySelector('.row-listen-btn');
    const delBtn = row.querySelector('.row-del-btn');

    runOneBtn.addEventListener('click', async () => {
      await executeSingleRow(row, true);
    });

    saveOneBtn.addEventListener('click', () => {
      const cb = (row.querySelector('.row-title').value.trim() || 'image').replace(/\.(jpg|jpeg|png|webp)$/i, '');
      const fn = `${cb}.jpg`;
      const blob = savedBlobs.get(fn);
      if (blob) {
        triggerSingleImageDownload(fn, blob);
      } else {
        showToast('Generate this row first using ▶ Run before saving.', true);
      }
    });

    openUrlBtn.addEventListener('click', () => {
      const seedVal = Math.floor(100000 + Math.random() * 899999);
      const url = buildTargetPollinationsUrl(row, seedVal, 'flux');
      window.open(url, '_blank', 'noopener');
      logDebug(`↗ Opened manual browser tab for ${row.querySelector('.row-title').value}`, 'info');
    });

    copyPromptBtn.addEventListener('click', async () => {
      const cleanPrompt = buildCleanFullPrompt(row);
      await copyTextSafe(cleanPrompt);
      showToast(`Copied clean prompt for ${row.querySelector('.row-title').value}`);
      logDebug(`📋 Copied clean prompt (no %20) for ${row.querySelector('.row-title').value}`, 'ok');
    });

    copyUrlBtn.addEventListener('click', async () => {
      const seedVal = Math.floor(100000 + Math.random() * 899999);
      const url = buildTargetPollinationsUrl(row, seedVal, 'flux');
      await copyTextSafe(url);
      showToast(`Copied URL for ${row.querySelector('.row-title').value}`);
      logDebug(`🔗 Copied manual URL for ${row.querySelector('.row-title').value}`, 'ok');
    });

    listenBtn.addEventListener('click', () => {
      const titleVal = row.querySelector('.row-title').value;
      const sceneVal = row.querySelector('.row-scene').value;
      speakText(`File ${titleVal}. ${sceneVal}`);
    });

    delBtn.addEventListener('click', () => {
      row.remove();
      updateRowIndices();
    });

    queueBody.appendChild(row);
    updateRowIndices();
    return row;
  }

  // --- Quick Multi-Line Composer Handlers ---
  toggleComposerBtn.addEventListener('click', () => {
    const isHidden = quickComposerBox.style.display === 'none';
    quickComposerBox.style.display = isHidden ? 'block' : 'none';
  });

  function parseComposerLines() {
    const raw = quickComposerInput.value.trim();
    if (!raw) {
      showToast('Enter at least one scene description line first.', true);
      return [];
    }
    const lines = raw.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const baseIdx = queueBody.querySelectorAll('tr').length + 1;
    return lines.map((line, i) => {
      if (line.includes('|')) {
        const sep = line.indexOf('|');
        return {
          title: line.slice(0, sep).trim() || `custom_${baseIdx + i}.jpg`,
          scene: line.slice(sep + 1).trim()
        };
      }
      return {
        title: `custom_${String(baseIdx + i).padStart(3, '0')}.jpg`,
        scene: line
      };
    });
  }

  appendComposerRowsBtn.addEventListener('click', () => {
    const items = parseComposerLines();
    if (items.length === 0) return;
    items.forEach(it => addRow(it.title, it.scene, globalStylePrefixInput.value.trim()));
    showToast(`Appended ${items.length} row(s) to queue.`);
    logDebug(`✨ Appended ${items.length} custom scene line(s) from Quick Composer.`, 'ok');
  });

  replaceComposerRowsBtn.addEventListener('click', () => {
    const items = parseComposerLines();
    if (items.length === 0) return;
    queueBody.innerHTML = '';
    items.forEach(it => addRow(it.title, it.scene, globalStylePrefixInput.value.trim()));
    showToast(`Replaced queue with ${items.length} custom row(s).`);
    logDebug(`✨ Replaced queue with ${items.length} custom scene line(s).`, 'ok');
  });

  openFirstComposerUrlBtn.addEventListener('click', () => {
    const items = parseComposerLines();
    if (items.length === 0) return;
    const tempRow = addRow(items[0].title, items[0].scene, globalStylePrefixInput.value.trim());
    const seedVal = Math.floor(100000 + Math.random() * 899999);
    const url = buildTargetPollinationsUrl(tempRow, seedVal, 'flux');
    window.open(url, '_blank', 'noopener');
    showToast('Encoded and opened URL in new tab.');
  });

  applyGlobalStyleBtn.addEventListener('click', () => {
    const shared = globalStylePrefixInput.value.replace(/#/g, '').trim();
    saveSetting('globalStylePrefix', shared);
    queueBody.querySelectorAll('.row-style-prefix').forEach(el => {
      el.value = shared;
    });
    showToast('Applied shared style prefix to all rows.');
    logDebug('Applied Shared Repeating Style Prefix to all rows in the queue.', 'ok');
  });

  // --- Restore Persisted Images from IndexedDB on Startup ---
  const restoredRecords = await loadAllFromVaultDB();
  if (restoredRecords.length > 0) {
    const folderName = dirNameInput.value.trim() || 'chapters_0014_0028_images';
    const folder = masterZip.folder(folderName);
    for (const rec of restoredRecords) {
      if (!rec.blob || !rec.fileName) continue;
      savedBlobs.set(rec.fileName, rec.blob);
      if (rec.sha256) seenImageHashes.add(rec.sha256);
      if (rec.dhash) seenDHashes.push(rec.dhash);
      folder.file(rec.fileName, rec.blob);
      galleryItems.push({
        fileName: rec.fileName,
        blob: rec.blob,
        objectUrl: URL.createObjectURL(rec.blob),
        fullPrompt: rec.fullPrompt || '',
        targetUrl: rec.targetUrl || '',
        providerLabel: rec.providerLabel || 'Restored from Vault',
        dims: rec.dims || ''
      });
    }
    showGalleryIndex(galleryItems.length - 1);
    logDebug(`♻️ Restored ${restoredRecords.length} previously confirmed image(s) from IndexedDB vault!`, 'ok');
  }

  // --- Load Bundled 99 Prompts ---
  function loadBundledChapterSet(filterVal = 'all') {
    const allItems = window.BUNDLED_PROMPTS_ALL || window.BUNDLED_PROMPTS_16_28 || [];
    queueBody.innerHTML = '';

    let filtered = allItems;
    if (filterVal === 'missing_14_15') {
      filtered = allItems.filter(item => item.chapter === 0 || item.chapter === 14 || item.chapter === 15);
    } else if (filterVal === '16_28') {
      filtered = allItems.filter(item => item.chapter >= 16);
    } else if (filterVal !== 'all') {
      filtered = allItems.filter(item => String(item.chapter) === String(filterVal));
    }

    filtered.forEach(item => {
      addRow(item.title, item.scene || item.prompt, item.stylePrefix || DEFAULT_BOOK_STYLE);
    });

    updateVaultBadge();
    updateRowIndices();
    logDebug(`Loaded ${filtered.length} prompts into queue (Filter: ${filterVal}).`, 'info');
  }

  loadBundledChapterSet('all');
  loadBundledBtn.addEventListener('click', () => loadBundledChapterSet(chapterFilter.value));

  clearQueueBtn.addEventListener('click', () => {
    queueBody.innerHTML = '';
    addRow('narr0014_imga.jpg', 'Scene: ', globalStylePrefixInput.value.trim());
  });

  addRowBtn.addEventListener('click', () => {
    const nextNum = queueBody.querySelectorAll('tr').length + 1;
    addRow(`img_${String(nextNum).padStart(2, '0')}.jpg`, 'Scene: ', globalStylePrefixInput.value.trim());
  });

  // --- 6. Cryptographic SHA-256 + Perceptual 64-Bit dHash + True JPEG Normalizer ---
  async function computeBlobSha256(blob) {
    const buffer = await blob.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  function hammingDistance(h1, h2) {
    if (!h1 || !h2 || h1.length !== h2.length) return 64;
    let dist = 0;
    for (let i = 0; i < h1.length; i++) {
      if (h1[i] !== h2[i]) dist++;
    }
    return dist;
  }

  /**
   * Decodes image onto an HTML5 Canvas:
   * 1. Computes 64-bit Perceptual Difference Hash (9x8 grayscale dHash) + pixel standard deviation (catches blank plates)
   * 2. Applies Smart Pre-Pad Trim or Standard Bottom Trim if enabled
   * 3. Re-encodes to clean baseline JPEG (image/jpeg, 0.95) so WebP/PNG never break build_smoke.py
   */
  async function processAndVerifyImageBlob(rawBlob, targetDims) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const objectUrl = URL.createObjectURL(rawBlob);
      img.onload = () => {
        URL.revokeObjectURL(objectUrl);
        const srcW = img.naturalWidth || img.width;
        const srcH = img.naturalHeight || img.height;
        if (srcW < 64 || srcH < 64) {
          reject(new Error(`Image dimensions too small (${srcW}x${srcH})`));
          return;
        }

        // 1. Compute 9x8 Perceptual dHash & Pixel Entropy
        const hashCanvas = document.createElement('canvas');
        hashCanvas.width = 9;
        hashCanvas.height = 8;
        const hCtx = hashCanvas.getContext('2d');
        hCtx.drawImage(img, 0, 0, 9, 8);
        const px = hCtx.getImageData(0, 0, 9, 8).data;
        const gray = [];
        for (let i = 0; i < px.length; i += 4) {
          gray.push(0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]);
        }
        const mean = gray.reduce((a, b) => a + b, 0) / gray.length;
        const variance = gray.reduce((a, b) => a + (b - mean) * (b - mean), 0) / gray.length;
        const stdDev = Math.sqrt(variance);

        if (stdDev < 4.5) {
          reject(new Error(`Blank or solid-color error plate rejected (pixel stdDev=${stdDev.toFixed(1)})`));
          return;
        }

        let dhash = '';
        for (let row = 0; row < 8; row++) {
          for (let col = 0; col < 8; col++) {
            const left = gray[row * 9 + col];
            const right = gray[row * 9 + col + 1];
            dhash += left < right ? '1' : '0';
          }
        }

        // 2. Determine Crop Height according to Watermark / Dimension Mode
        const trimMode = trimModeSelect.value;
        const trimPx = Math.max(0, Number(trimPxInput.value) || 0);
        let outW = srcW;
        let outH = srcH;

        if (trimMode === 'prepad_trim' && trimPx > 0) {
          if (srcH > targetDims.height) {
            outH = targetDims.height;
          } else {
            outH = Math.max(srcH - trimPx, Math.floor(srcH * 0.9));
          }
        } else if (trimMode === 'standard_trim' && trimPx > 0) {
          outH = Math.max(srcH - trimPx, Math.floor(srcH * 0.9));
        }

        const outCanvas = document.createElement('canvas');
        outCanvas.width = outW;
        outCanvas.height = outH;
        const outCtx = outCanvas.getContext('2d');
        outCtx.fillStyle = '#ede4d4';
        outCtx.fillRect(0, 0, outW, outH);
        outCtx.drawImage(img, 0, 0, outW, outH, 0, 0, outW, outH);

        outCanvas.toBlob((jpegBlob) => {
          if (!jpegBlob) {
            reject(new Error('Canvas JPEG normalization failed'));
            return;
          }
          resolve({
            blob: jpegBlob,
            dhash,
            stdDev,
            dims: `${outW}×${outH}`
          });
        }, 'image/jpeg', 0.94);
      };
      img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('Payload is not a valid decodable image'));
      };
      img.src = objectUrl;
    });
  }

  // --- 7. Timeout-Guarded Fetch Helper ---
  async function fetchWithAttemptTimeout(url, options, timeoutSec, parentSignal) {
    const controller = new AbortController();
    const onParentAbort = () => controller.abort();
    if (parentSignal) parentSignal.addEventListener('abort', onParentAbort, { once: true });
    const timer = setTimeout(() => controller.abort(), timeoutSec * 1000);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
      if (parentSignal) parentSignal.removeEventListener('abort', onParentAbort);
    }
  }

  // --- 8. Multi-Provider / Multi-Key Generation Adapters ---
  async function generateViaGeminiKey(apiKey, promptText, timeoutSec, signal) {
    const imagenUrl = `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=${encodeURIComponent(apiKey)}`;
    const res1 = await fetchWithAttemptTimeout(imagenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        instances: [{ prompt: promptText }],
        parameters: { sampleCount: 1, aspectRatio: '16:9', outputOptions: { mimeType: 'image/jpeg' } }
      })
    }, timeoutSec, signal);

    if (res1.ok) {
      const data = await res1.json();
      const b64 = data?.predictions?.[0]?.bytesBase64Encoded;
      if (b64) {
        const bin = atob(b64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return new Blob([bytes], { type: 'image/jpeg' });
      }
    }

    const flashUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp-image-generation:generateContent?key=${encodeURIComponent(apiKey)}`;
    const res2 = await fetchWithAttemptTimeout(flashUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: promptText }] }],
        generationConfig: { responseModalities: ['TEXT', 'IMAGE'] }
      })
    }, timeoutSec, signal);

    if (!res2.ok) throw new Error(`Gemini API HTTP ${res2.status}`);
    const data2 = await res2.json();
    const parts = data2?.candidates?.[0]?.content?.parts || [];
    const imgPart = parts.find(p => p.inlineData && p.inlineData.data);
    if (!imgPart) throw new Error('Gemini response did not contain inline image bytes');
    const bin = atob(imgPart.inlineData.data);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: imgPart.inlineData.mimeType || 'image/jpeg' });
  }

  async function generateViaHuggingFaceKey(apiKey, promptText, timeoutSec, signal) {
    const hfUrl = 'https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell';
    const res = await fetchWithAttemptTimeout(hfUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ inputs: promptText })
    }, timeoutSec, signal);
    if (!res.ok) throw new Error(`HuggingFace HTTP ${res.status}`);
    return await res.blob();
  }

  async function generateViaOpenAIKey(apiKey, promptText, timeoutSec, signal) {
    const res = await fetchWithAttemptTimeout('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'dall-e-3',
        prompt: promptText.slice(0, 3900),
        n: 1,
        size: '1792x1024',
        response_format: 'b64_json'
      })
    }, timeoutSec, signal);
    if (!res.ok) throw new Error(`OpenAI HTTP ${res.status}`);
    const data = await res.json();
    const b64 = data?.data?.[0]?.b64_json;
    if (!b64) throw new Error('OpenAI returned no image data');
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: 'image/jpeg' });
  }

  async function generateViaAiHorde(apiKey, promptText, timeoutSec, signal) {
    const keyToUse = apiKey || '0000000000';
    const initRes = await fetchWithAttemptTimeout('https://aihorde.net/api/v2/generate/async', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': keyToUse,
        'Client-Agent': 'BatchImagePipeline:3.0:KiwiExtension'
      },
      body: JSON.stringify({
        prompt: promptText,
        params: {
          width: keyToUse === '0000000000' ? 576 : 1024,
          height: keyToUse === '0000000000' ? 320 : 576,
          steps: 20,
          n: 1
        },
        r2: true
      })
    }, timeoutSec, signal);
    if (!initRes.ok) throw new Error(`AI Horde submit HTTP ${initRes.status}`);
    const { id } = await initRes.json();
    if (!id) throw new Error('AI Horde returned no job ID');

    for (let poll = 0; poll < 22; poll++) {
      await new Promise(r => setTimeout(r, 4000));
      if (signal && signal.aborted) throw new Error('Cancelled');
      const statusRes = await fetchWithAttemptTimeout(`https://aihorde.net/api/v2/generate/status/${id}`, {}, 15, signal);
      if (!statusRes.ok) continue;
      const st = await statusRes.json();
      if (st.done && st.generations && st.generations.length > 0) {
        const imgSource = st.generations[0].img;
        if (imgSource.startsWith('http')) {
          const imgFetch = await fetchWithAttemptTimeout(imgSource, {}, timeoutSec, signal);
          return await imgFetch.blob();
        } else {
          const bin = atob(imgSource);
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          return new Blob([bytes], { type: 'image/webp' });
        }
      }
      if (st.faulted) throw new Error('AI Horde job faulted');
    }
    throw new Error('AI Horde timed out');
  }

  async function generateViaPollinations(row, modelName, seedVal, apiKeyObj, timeoutSec, signal) {
    const targetUrl = buildTargetPollinationsUrl(row, seedVal, modelName);
    const headers = {};
    let finalUrl = targetUrl;

    if (apiKeyObj && apiKeyObj.key) {
      headers['Authorization'] = `Bearer ${apiKeyObj.key}`;
      finalUrl += `&key=${encodeURIComponent(apiKeyObj.key)}`;
    }

    const res = await fetchWithAttemptTimeout(finalUrl, { headers, cache: 'no-store' }, timeoutSec, signal);
    if (!res.ok) {
      throw new Error(`Pollinations (${modelName}) HTTP ${res.status}`);
    }
    const blob = await res.blob();
    return { blob, targetUrl };
  }

  // --- 9. Countdown Timer with Pause & Cancel Support ---
  async function waitWhilePaused() {
    while (isPaused && !isCancelled) {
      countdownPill.style.display = 'inline-block';
      countdownPill.textContent = '⏸ Paused';
      await new Promise(r => setTimeout(r, 400));
    }
  }

  async function sleepWithCountdown(totalMs, labelPrefix = 'Cooling down') {
    let remainingSec = Math.ceil(totalMs / 1000);
    countdownPill.style.display = 'inline-block';
    while (remainingSec > 0 && !isCancelled) {
      await waitWhilePaused();
      if (isCancelled) break;
      countdownPill.textContent = `⏳ ${labelPrefix}: ${remainingSec}s`;
      await new Promise(r => setTimeout(r, 1000));
      remainingSec--;
    }
    countdownPill.style.display = 'none';
  }

  // --- 10. Execute Single Row with SHA-256 + Perceptual dHash + IndexedDB + Local Disk Save ---
  async function executeSingleRow(row, isManualSingleRun = false) {
    const rawTitle = row.querySelector('.row-title').value.trim();
    const cleanBase = (rawTitle || 'image').replace(/\.(jpg|jpeg|png|webp)$/i, '');
    const rowFileName = `${cleanBase}.jpg`;
    const statusTag = row.querySelector('.row-status-tag');
    const saveOneBtn = row.querySelector('.row-save-btn');
    const fullPrompt = buildCleanFullPrompt(row);
    const targetDims = getRowTargetDimensions(row);
    const timeoutSec = Math.max(10, Number(reqTimeoutSecInput.value) || 35);

    if (!fullPrompt) {
      showToast('Scene description is empty for this row.', true);
      return false;
    }

    row.classList.remove('completed-row', 'error-row');
    row.classList.add('active-row');
    statusTag.className = 'row-status-tag run';
    statusTag.textContent = 'Running...';

    if (proxyToggle.checked && cycleProxyEveryReq.checked) {
      await switchProxyNext(false);
    }

    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      if (isCancelled && !isManualSingleRun) {
        statusTag.className = 'row-status-tag err';
        statusTag.textContent = 'Cancelled';
        return false;
      }
      await waitWhilePaused();

      activeAbortController = new AbortController();
      const signal = activeAbortController.signal;

      const mode = providerModeSelect.value;
      const seedVal = Math.floor(100000 + Math.random() * 899999);
      let keyObj = null;
      if (savedApiKeys.length > 0) {
        keyObj = savedApiKeys[keyCursor % savedApiKeys.length];
        keyCursor++;
      }

      const modelName = POLLINATIONS_MODELS[modelCursor % POLLINATIONS_MODELS.length];
      modelCursor++;

      let providerLabel = `Pollinations (${modelName}, seed=${seedVal})`;
      let targetUrl = buildTargetPollinationsUrl(row, seedVal, modelName);

      try {
        let rawBlob = null;

        if (keyObj && (mode === 'smart_cycle' || mode === 'keys_only')) {
          providerLabel = `${providerDisplayName(keyObj.provider)} Key (${maskKeyString(keyObj.key)})`;
          logDebug(`[${rowFileName}] Attempt ${attempt}/${maxAttempts} via ${providerLabel}...`, 'info');
          statusMessage.textContent = `Generating "${rowFileName}" via ${providerLabel} (attempt ${attempt}/${maxAttempts})...`;

          if (keyObj.provider === 'gemini') {
            rawBlob = await generateViaGeminiKey(keyObj.key, fullPrompt, timeoutSec, signal);
          } else if (keyObj.provider === 'huggingface') {
            rawBlob = await generateViaHuggingFaceKey(keyObj.key, fullPrompt, timeoutSec, signal);
          } else if (keyObj.provider === 'openai') {
            rawBlob = await generateViaOpenAIKey(keyObj.key, fullPrompt, timeoutSec, signal);
          } else if (keyObj.provider === 'aihorde') {
            rawBlob = await generateViaAiHorde(keyObj.key, fullPrompt, timeoutSec, signal);
          } else {
            const r = await generateViaPollinations(row, modelName, seedVal, keyObj, timeoutSec, signal);
            rawBlob = r.blob;
            targetUrl = r.targetUrl;
          }
          keyObj.uses = (keyObj.uses || 0) + 1;
          saveSetting('savedApiKeys', savedApiKeys);
          renderKeyChips();
        } else if (mode === 'aihorde_cycle' || (mode === 'smart_cycle' && attempt === maxAttempts)) {
          providerLabel = 'AI Horde Cluster (0000000000)';
          logDebug(`[${rowFileName}] Attempt ${attempt}/${maxAttempts} via ${providerLabel}...`, 'info');
          statusMessage.textContent = `Generating "${rowFileName}" via ${providerLabel}...`;
          rawBlob = await generateViaAiHorde('0000000000', fullPrompt, timeoutSec, signal);
        } else {
          logDebug(`[${rowFileName}] Attempt ${attempt}/${maxAttempts} via ${providerLabel}...`, 'info');
          statusMessage.textContent = `Generating "${rowFileName}" via ${providerLabel} (attempt ${attempt}/${maxAttempts})...`;
          const r = await generateViaPollinations(row, modelName, seedVal, null, timeoutSec, signal);
          rawBlob = r.blob;
          targetUrl = r.targetUrl;
        }

        if (!rawBlob || rawBlob.size < 4500) {
          throw new Error(`Invalid/empty payload (${rawBlob ? rawBlob.size : 0} bytes)`);
        }

        // 1. Raw SHA-256 Check
        const rawSha256 = await computeBlobSha256(rawBlob);
        if (rejectDuplicatesCheckbox.checked && seenImageHashes.has(rawSha256)) {
          throw new Error(`Exact SHA-256 duplicate rejected (${rawSha256.slice(0, 10)}...)`);
        }

        // 2. Canvas Decode + 64-Bit Perceptual dHash + Pixel Entropy + Smart Pre-Pad Trim + Baseline JPEG Normalization
        const processed = await processAndVerifyImageBlob(rawBlob, targetDims);
        if (rejectDuplicatesCheckbox.checked) {
          const nearDup = seenDHashes.find(oldH => hammingDistance(oldH, processed.dhash) <= 4);
          if (nearDup) {
            throw new Error(`Perceptual dHash duplicate rejected (Hamming distance <= 4 to previous image — cached fallback portrait blocked!)`);
          }
        }

        const finalBlob = processed.blob;
        const finalSha256 = await computeBlobSha256(finalBlob);

        // 3. Write to JSZip & Verify
        const folderName = dirNameInput.value.trim() || 'chapters_0014_0028_images';
        const folder = masterZip.folder(folderName);
        folder.file(rowFileName, finalBlob);
        if (!folder.file(rowFileName)) {
          throw new Error(`JSZip folder verification failed for ${rowFileName}`);
        }

        // 4. Persist to IndexedDB Vault & Optional Local Disk Folder
        seenImageHashes.add(rawSha256);
        seenImageHashes.add(finalSha256);
        seenDHashes.push(processed.dhash);
        savedBlobs.set(rowFileName, finalBlob);

        await saveImageToVaultDB({
          fileName: rowFileName,
          blob: finalBlob,
          sha256: finalSha256,
          dhash: processed.dhash,
          fullPrompt,
          targetUrl,
          providerLabel,
          dims: processed.dims,
          savedAt: Date.now()
        });

        const wroteToDisk = await writeBlobToLocalDir(rowFileName, finalBlob);

        const objectUrl = URL.createObjectURL(finalBlob);
        galleryItems.push({
          fileName: rowFileName,
          blob: finalBlob,
          objectUrl,
          fullPrompt,
          targetUrl,
          providerLabel,
          dims: processed.dims
        });
        showGalleryIndex(galleryItems.length - 1);

        row.classList.remove('active-row', 'error-row');
        row.classList.add('completed-row');
        statusTag.className = 'row-status-tag done';
        statusTag.textContent = wroteToDisk ? '✅ Disk+Vault' : '✅ In Vault';
        saveOneBtn.disabled = false;
        updateVaultBadge();

        logDebug(
          `✅ CONFIRMED: "${folderName}/${rowFileName}" (${(finalBlob.size / 1024).toFixed(1)} KB, ${processed.dims}, dHash=${processed.dhash.slice(0, 12)}..., stdDev=${processed.stdDev.toFixed(1)}) saved to IndexedDB${wroteToDisk ? ' + Local Disk' : ''}.`,
          'ok'
        );
        return true;

      } catch (err) {
        if (signal.aborted && isCancelled) {
          logDebug(`⏹ Cancelled request for "${rowFileName}".`, 'warn');
          statusTag.className = 'row-status-tag err';
          statusTag.textContent = 'Cancelled';
          row.classList.remove('active-row');
          return false;
        }

        logDebug(`❌ Attempt ${attempt}/${maxAttempts} failed for "${rowFileName}": ${err.message}`, 'err');

        if (proxyToggle.checked) {
          await switchProxyNext(true);
        }

        if (attempt < maxAttempts) {
          const waitSec = isManualSingleRun ? 6 : Math.max(Number(cooldownSecInput.value) || 45, 5);
          statusMessage.textContent = `Attempt ${attempt} failed (${err.message}). Switched proxy/model — cooling down ${waitSec}s...`;
          await sleepWithCountdown(waitSec * 1000, `Retry ${attempt + 1} in`);
        }
      }
    }

    row.classList.remove('active-row');
    row.classList.add('error-row');
    statusTag.className = 'row-status-tag err';
    statusTag.textContent = '❌ Failed';
    logDebug(`⛔ All ${maxAttempts} attempts exhausted for "${rowFileName}".`, 'err');
    return false;
  }

  // --- 11. Batch Runner with Cancel / Pause / Zip Export ---
  cancelBatchBtn.addEventListener('click', () => {
    if (!isRunning) return;
    isCancelled = true;
    isPaused = false;
    if (activeAbortController) activeAbortController.abort();
    countdownPill.style.display = 'none';
    statusMessage.textContent = `⏹ Batch cancelled. ${savedBlobs.size} confirmed image(s) remain safe in IndexedDB & Zip Folder.`;
    logDebug(`⏹ Batch cancelled by user. ${savedBlobs.size} files preserved in Vault.`, 'warn');
  });

  pauseBatchBtn.addEventListener('click', () => {
    if (!isRunning) return;
    isPaused = !isPaused;
    pauseBatchBtn.textContent = isPaused ? '▶ Resume Queue' : '⏸ Pause Queue';
    logDebug(isPaused ? '⏸ Queue paused by user.' : '▶ Queue resumed by user.', 'warn');
  });

  async function downloadMasterZip() {
    if (savedBlobs.size === 0) {
      showToast('No confirmed images in the folder yet.', true);
      return;
    }
    const folderName = dirNameInput.value.trim() || 'chapters_0014_0028_images';
    savePartialBtn.disabled = true;
    const origText = savePartialBtn.textContent;
    savePartialBtn.textContent = 'Compressing Zip...';
    logDebug(`📦 Compiling JSZip archive "${folderName}.zip" with ${savedBlobs.size} confirmed files...`, 'info');

    try {
      const content = await masterZip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 }
      });
      const link = document.createElement('a');
      const url = URL.createObjectURL(content);
      link.href = url;
      link.download = `${folderName}.zip`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      showToast(`Downloaded ${folderName}.zip (${savedBlobs.size} images)`);
      logDebug(`✅ Downloaded "${folderName}.zip" (${(content.size / 1024).toFixed(1)} KB, ${savedBlobs.size} images).`, 'ok');
    } finally {
      savePartialBtn.disabled = false;
      savePartialBtn.textContent = origText;
    }
  }

  savePartialBtn.addEventListener('click', downloadMasterZip);

  runBatchBtn.addEventListener('click', async () => {
    const rows = Array.from(queueBody.querySelectorAll('tr'));
    if (rows.length === 0) {
      showToast('Queue is empty.', true);
      return;
    }

    const startIdx = Math.max(0, (Number(startRowInput.value) || 1) - 1);
    isRunning = true;
    isPaused = false;
    isCancelled = false;

    runBatchBtn.disabled = true;
    pauseBatchBtn.disabled = false;
    cancelBatchBtn.disabled = false;
    pauseBatchBtn.textContent = '⏸ Pause Queue';

    logDebug(`🚀 Starting batch from Row #${startIdx + 1} of ${rows.length}...`, 'info');

    try {
      for (let i = startIdx; i < rows.length; i++) {
        if (isCancelled) break;
        await waitWhilePaused();
        if (isCancelled) break;

        const row = rows[i];
        const rawTitle = row.querySelector('.row-title').value.trim();
        const cleanBase = (rawTitle || `image_${i + 1}`).replace(/\.(jpg|jpeg|png|webp)$/i, '');
        const fileName = `${cleanBase}.jpg`;

        if (savedBlobs.has(fileName)) {
          logDebug(`Skipping Row #${i + 1} (${fileName}) — already confirmed in IndexedDB Vault.`, 'info');
          continue;
        }

        row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        progressBar.style.width = `${Math.round((i / rows.length) * 100)}%`;

        const ok = await executeSingleRow(row, false);
        if (isCancelled) break;

        if (ok && i + 2 <= rows.length) {
          startRowInput.value = i + 2;
          saveSetting('startRow', i + 2);
        }

        if (i < rows.length - 1 && !isCancelled) {
          const baseDelay = Math.max(Number(delaySecInput.value) || 20, 2);
          const jitter = Math.floor(Math.random() * ((Number(jitterSecInput.value) || 5) + 1));
          const waitSec = baseDelay + jitter;
          statusMessage.textContent = `Confirmed Row #${i + 1}. Pacing ${waitSec}s (${baseDelay}s + ${jitter}s jitter) before Row #${i + 2}...`;
          logDebug(`⏳ Waiting ${waitSec}s inter-request cooldown before Row #${i + 2}...`, 'info');
          await sleepWithCountdown(waitSec * 1000, `Next prompt in`);
        }
      }

      progressBar.style.width = '100%';
      if (!isCancelled && savedBlobs.size > 0) {
        await downloadMasterZip();
      }
    } finally {
      isRunning = false;
      isPaused = false;
      runBatchBtn.disabled = false;
      pauseBatchBtn.disabled = true;
      cancelBatchBtn.disabled = true;
      countdownPill.style.display = 'none';
    }
  });

  // --- 12. Import & Export Queue Handlers (.md, .txt, .csv, .json) ---
  importBtn.addEventListener('click', () => importFile.click());

  importFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = String(ev.target.result || '').replace(/\r\n/g, '\n').trim();
      if (!text) return;

      const parsed = [];
      const mdRegex = /###\s+[^\n]*?file\s+`([^`]+)`[^\n]*\n+([^\n]+)/g;
      let m;
      while ((m = mdRegex.exec(text)) !== null) {
        parsed.push({ title: m[1].trim(), prompt: m[2].trim() });
      }

      if (parsed.length === 0) {
        const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
        for (const line of lines) {
          if (line.startsWith('#') || line.startsWith('>')) continue;
          if (line.includes('|')) {
            const idx = line.indexOf('|');
            const t = line.slice(0, idx).trim();
            const p = line.slice(idx + 1).trim();
            if (t.toLowerCase() !== 'file title' && p) parsed.push({ title: t, prompt: p });
          } else {
            parsed.push({ title: `img_${parsed.length + 1}.jpg`, prompt: line });
          }
        }
      }

      if (parsed.length > 0) {
        queueBody.innerHTML = '';
        parsed.forEach(item => addRow(item.title, item.prompt));
        showToast(`Imported ${parsed.length} rows from ${file.name}`);
        logDebug(`📂 Imported ${parsed.length} rows from ${file.name}.`, 'ok');
      }
    };
    reader.readAsText(file);
    importFile.value = '';
  });

  exportBtn.addEventListener('click', () => {
    const rows = Array.from(queueBody.querySelectorAll('tr'));
    const data = rows.map(r => ({
      title: r.querySelector('.row-title').value.trim(),
      scene: r.querySelector('.row-scene').value.trim(),
      stylePrefix: r.querySelector('.row-style-prefix').value.trim(),
      fullPrompt: buildCleanFullPrompt(r),
      url: buildTargetPollinationsUrl(r, null, 'flux')
    }));
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${dirNameInput.value.trim() || 'queue'}_v3_export.json`;
    link.click();
    showToast(`Exported ${data.length} rows to JSON.`);
    logDebug(`Exported ${data.length} rows to JSON.`, 'ok');
  });

  exportMdBtn.addEventListener('click', () => {
    const rows = Array.from(queueBody.querySelectorAll('tr'));
    const mdLines = ['# Complete Image Prompts (Cover + Chapters 14–28)\n'];
    rows.forEach((r, idx) => {
      const fn = r.querySelector('.row-title').value.trim();
      const fullP = buildCleanFullPrompt(r);
      const url = buildTargetPollinationsUrl(r, null, 'flux');
      mdLines.append ? null : null;
      mdLines.push(`### ${idx + 1} (\`[[IMAGE ${idx + 1}]]\`, file \`${fn}\`)\n\n${fullP}\n\n[Generate](${url})\n`);
    });
    const blob = new Blob([mdLines.join('\n')], { type: 'text/markdown' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'image-prompts-0014-0028-complete.md';
    link.click();
    showToast(`Exported ${rows.length} prompts to Markdown (.md)`);
    logDebug(`📝 Exported ${rows.length} prompts to image-prompts-0014-0028-complete.md (compatible with build_smoke.py).`, 'ok');
  });
});
