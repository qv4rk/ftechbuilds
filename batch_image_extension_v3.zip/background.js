/**
 * Background Service Worker v3.0:
 * - Persists badProxies, customProxies, and cursor in chrome.storage.local so MV3 30s service-worker sleep never resets state
 * - Bypasses free proxy for authenticated API endpoints (Gemini, HuggingFace, OpenAI, AI Horde) so dead proxies never break paid/token API calls
 * - Supports pre-flight proxy latency testing ("Test & Prune Proxy Pool")
 */

const PROXY_SOURCES = [
  { url: 'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=ipport&format=text&timeout=5000', scheme: 'http' },
  { url: 'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt', scheme: 'socks5' },
  { url: 'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt', scheme: 'http' },
  { url: 'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt', scheme: 'socks5' },
  { url: 'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt', scheme: 'http' }
];

let cache = { list: [], at: 0, cursor: 0 };

const shuffle = (arr) => arr.map(v => [Math.random(), v]).sort((a, b) => a[0] - b[0]).map(p => p[1]);

async function getPersistedProxyState() {
  const data = await chrome.storage.local.get(['badProxiesArr', 'customProxiesArr', 'proxyCursor']);
  return {
    badSet: new Set(Array.isArray(data.badProxiesArr) ? data.badProxiesArr : []),
    customList: Array.isArray(data.customProxiesArr) ? data.customProxiesArr : [],
    cursor: typeof data.proxyCursor === 'number' ? data.proxyCursor : 0
  };
}

async function savePersistedProxyState(badSet, customList, cursor) {
  await chrome.storage.local.set({
    badProxiesArr: Array.from(badSet).slice(-2000),
    customProxiesArr: customList,
    proxyCursor: cursor
  });
}

function setProxy({ scheme = 'http', host, port }) {
  return new Promise((resolve) => {
    chrome.proxy.settings.set({
      value: {
        mode: 'fixed_servers',
        rules: {
          singleProxy: { scheme, host, port: Number(port) },
          bypassList: [
            'localhost',
            '127.0.0.1',
            '<local>',
            'generativelanguage.googleapis.com',
            'router.huggingface.co',
            'api-inference.huggingface.co',
            'api.openai.com',
            'aihorde.net',
            'stablehorde.net',
            'raw.githubusercontent.com',
            'api.proxyscrape.com'
          ]
        }
      },
      scope: 'regular'
    }, resolve);
  });
}

function clearProxy() {
  return new Promise((resolve) => {
    chrome.proxy.settings.clear({ scope: 'regular' }, resolve);
  });
}

function parseProxyLines(text, defaultScheme = 'http') {
  const out = [];
  const lines = String(text || '').split(/\r?\n/);
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const m = line.match(/^(?:(http|https|socks4|socks5):\/\/)?(\d{1,3}(?:\.\d{1,3}){3}):(\d{1,5})$/i);
    if (m) {
      const scheme = m[1] ? m[1].toLowerCase() : defaultScheme;
      const host = m[2];
      const port = Number(m[3]);
      if (port > 0 && port <= 65535) {
        out.push({ scheme: scheme === 'https' ? 'http' : scheme, host, port });
      }
    }
  }
  return out;
}

async function loadProxies(forceRefresh = false) {
  const { badSet, customList } = await getPersistedProxyState();
  if (!forceRefresh && cache.list.length > 0 && Date.now() - cache.at < 15 * 60 * 1000) {
    return cache.list.filter(p => !badSet.has(`${p.host}:${p.port}`));
  }

  const results = await Promise.allSettled(
    PROXY_SOURCES.map(src =>
      fetch(src.url, { cache: 'no-store' })
        .then(r => (r.ok ? r.text() : ''))
        .then(text => parseProxyLines(text, src.scheme))
    )
  );

  const seen = new Set();
  const combined = [];

  for (const p of customList) {
    const key = `${p.host}:${p.port}`;
    if (!seen.has(key) && !badSet.has(key)) {
      seen.add(key);
      combined.push(p);
    }
  }

  for (const r of results) {
    if (r.status !== 'fulfilled' || !Array.isArray(r.value)) continue;
    for (const p of r.value) {
      const key = `${p.host}:${p.port}`;
      if (!seen.has(key) && !badSet.has(key)) {
        seen.add(key);
        combined.push(p);
      }
    }
  }

  const shuffled = shuffle(combined);
  cache = { list: shuffled, at: Date.now(), cursor: 0 };
  return shuffled;
}

async function switchNextProxy({ markCurrentBad = false } = {}) {
  const { badSet, customList, cursor } = await getPersistedProxyState();
  const saved = await chrome.storage.local.get(['activeProxy']);
  if (markCurrentBad && saved && saved.activeProxy) {
    badSet.add(`${saved.activeProxy.host}:${saved.activeProxy.port}`);
  }

  const pool = await loadProxies(false);
  if (pool.length === 0) {
    await clearProxy();
    await chrome.storage.local.set({ proxyEnabled: false, activeProxy: null });
    return {
      ok: false,
      error: 'Proxy pool exhausted or unreachable.',
      totalLoaded: 0,
      badCount: badSet.size
    };
  }

  const nextCursor = (cursor + 1) % pool.length;
  const candidate = pool[nextCursor];
  await setProxy(candidate);
  await savePersistedProxyState(badSet, customList, nextCursor);
  await chrome.storage.local.set({ proxyEnabled: true, activeProxy: candidate });

  return {
    ok: true,
    proxy: candidate,
    ip: `${candidate.scheme}://${candidate.host}:${candidate.port}`,
    totalLoaded: pool.length,
    badCount: badSet.size
  };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'toggleProxy') {
    if (msg.enabled) {
      switchNextProxy({ markCurrentBad: false }).then(sendResponse);
    } else {
      clearProxy().then(async () => {
        const { badSet } = await getPersistedProxyState();
        await chrome.storage.local.set({ proxyEnabled: false, activeProxy: null });
        sendResponse({
          ok: true,
          enabled: false,
          totalLoaded: cache.list.length,
          badCount: badSet.size
        });
      });
    }
    return true;
  }

  if (msg.action === 'rotateProxy' || msg.action === 'cycleNextProxy') {
    switchNextProxy({ markCurrentBad: !!msg.markBad }).then(sendResponse);
    return true;
  }

  if (msg.action === 'refreshProxyPool') {
    getPersistedProxyState().then(async ({ customList }) => {
      await savePersistedProxyState(new Set(), customList, 0);
      const list = await loadProxies(true);
      sendResponse({ ok: true, totalLoaded: list.length, badCount: 0 });
    });
    return true;
  }

  if (msg.action === 'importProxyText') {
    getPersistedProxyState().then(async ({ badSet, customList, cursor }) => {
      const parsed = parseProxyLines(msg.text || '', msg.scheme || 'http');
      const updatedCustom = [...parsed, ...customList];
      await savePersistedProxyState(badSet, updatedCustom, cursor);
      const list = await loadProxies(true);
      sendResponse({
        ok: parsed.length > 0,
        importedCount: parsed.length,
        totalLoaded: list.length,
        badCount: badSet.size
      });
    });
    return true;
  }

  if (msg.action === 'getProxyStats') {
    Promise.all([loadProxies(false), getPersistedProxyState(), chrome.storage.local.get(['proxyEnabled', 'activeProxy'])])
      .then(([list, { badSet }, saved]) => {
        sendResponse({
          ok: true,
          totalLoaded: list.length,
          badCount: badSet.size,
          proxyEnabled: !!(saved && saved.proxyEnabled),
          activeProxy: (saved && saved.activeProxy) || null
        });
      });
    return true;
  }
});

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
});
