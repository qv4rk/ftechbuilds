# Batch Image Pipeline v3.0 (Chrome / Kiwi Browser Extension & Standalone Web Studio)

## What's New in v3.0
1. **All 99 Manuscript Prompts Pre-Loaded (`presets.js`)**:
   - Adds the revised **Front Cover** (`cover_main.jpg`) with the 6 marginal ink-and-wash vignettes.
   - Adds the **14 missing scene prompts for Chapters 14 & 15** (`narr0014_imga.jpg`–`narr0014_imgg.jpg` and `narr0015_imga.jpg`–`narr0015_imgg.jpg`) extracted directly from the `[[IMAGE 1]]`–`[[IMAGE 7]]` placeholders in `Smoke_on_the_Mediterranean_full.docx`.
   - Includes all **84 prompts for Chapters 16–28** (`narr0016_imga.jpg`–`narr0028_imgg.jpg`).
2. **Crash-Proof IndexedDB Image Vault (`BatchImageVaultDB_v3`)**:
   - Every confirmed image is immediately saved to browser IndexedDB storage. Refreshing the tab, putting your phone to sleep in Kiwi Browser, or restarting Chrome never loses a single generated image.
3. **Smart Pre-Pad Watermark Trim (Exact `1536×864` 16:9 Output)**:
   - Requests `Target Height + TrimPx` (e.g., `1536×888` when trimming `24px`) and crops `24px` off the bottom on save—removing bottom watermarks while keeping the final image at exact `1536×864` (16:9).
4. **64-Bit Perceptual `dHash` + Pixel-Entropy Gate**:
   - Rejects re-compressed duplicate fallback images (Hamming distance <= 4) and blank/solid-color error plates (pixel standard deviation < 4.5) even when their raw SHA-256 bytes differ.
5. **True Baseline JPEG Normalization**:
   - Re-encodes WebP (AI Horde) and PNG (Gemini/HuggingFace) responses into baseline JPEG (`image/jpeg`) so `build_smoke.py` (`fpdf2` and `python-docx`) never crashes on mismatched headers.
6. **MV3 Persistent Proxy Pool + Authenticated API Bypass + Attempt Timeout**:
   - Saves blacklisted proxies and custom proxy lists to `chrome.storage.local` so Manifest V3 30-second service-worker sleep never resets the pool, bypasses free proxies for authenticated API endpoints, and aborts hung proxy connections after your configurable timeout.
7. **Direct Local Folder Auto-Save (`window.showDirectoryPicker`)**:
   - Link a local disk folder on desktop Chrome/Edge to write each `narrNNNN_imgX.jpg` directly to disk the instant it finishes.
8. **Quick Multi-Line Description-to-URL Composer & `.md` Exporter**:
   - Paste multiple raw scene descriptions (one per line) to convert them into URL-encoded queue rows, or export the full 99-prompt queue as a `build_smoke.py`-ready `.md` file.
